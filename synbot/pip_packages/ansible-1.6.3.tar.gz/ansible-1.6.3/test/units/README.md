Unit tests
==========

Tests at code level.   Should be concise and to the point, and organized by subject.

