# -*- coding: utf-8 -*-
"""
Predecessor of behave4cmd library.
Currently used to provide self-tests for behave.
"""
