.. _election_module:

:mod:`kazoo.recipe.election`
----------------------------

.. automodule:: kazoo.recipe.election

Public API
++++++++++

    .. autoclass:: Election
        :members:

        .. automethod:: __init__
