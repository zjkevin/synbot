===========
pyhs2
===========

pyHS2 is a python client driver for connecting to hive server 2.

See example.py for an example of how to use it.

Please log all issues/new feature requests under the issues tab and I will respond ASAP.

Contact @bradruderman or bradruderman@gmail.com with questions.

Enjoy